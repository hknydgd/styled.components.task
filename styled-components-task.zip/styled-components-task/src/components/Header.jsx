import { StyledHeader,Nav,Logo, Image } from "./styles/Header.styled"
import { Button } from "./styles/Button.styled"
import { Container } from "./styles/Container.styled"
import { Flex } from "./styles/Flex.styled"
function Header() {
  return (
    <StyledHeader>
      <Container>
     <Nav>
      <Logo src='./images/logo.svg' alt=''/>
      <Button>Try it Free</Button>
      </Nav>
      <Flex>
        <div>
          <h1>Build The Comminity Your Funs Will Love</h1>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Culpa numquam molestiae assumenda eaque illo adipisci corporis quibusdam doloribus provident accusantium repudiandae facilis ullam, vitae accusamus dignissimos alias fugit animi omnis dolores quisquam!</p>
          <Button bg='#ff0099' color='#fff'>Get Started Free</Button>
        </div>
        <Image src='./images/illustration-mockups.svg' alt=''/>
      </Flex>
      </Container>
      </StyledHeader>
  )
}

export default Header
